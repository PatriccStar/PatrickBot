﻿namespace NadekoBot.Modules.Games.Commands.Hangman
{
    public class HangmanObject
    {
        public string Word { get; set; }
        public string ImageUrl { get; set; }
    }
}
